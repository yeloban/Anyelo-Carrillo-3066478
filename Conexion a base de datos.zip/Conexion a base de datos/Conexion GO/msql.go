package main

import (
	"database/sql"
	"fmt"
	"log"
)

// Estructura para mapear datos
type Usuario struct {
	ID     int
	Nombre string
	Email  string
}

func main() {
	// 1. Configurar conexión
	db, err := sql.Open("mysql", "usuario:contraseña@tcp(127.0.0.1:3306)/basedatos")
	if err != nil {
		log.Fatal("Error al conectar:", err)
	}
	defer db.Close() // Cierra la conexión al final

	// 2. Verificar conexión
	err = db.Ping()
	if err != nil {
		log.Fatal("Error al hacer ping:", err)
	}
	fmt.Println("✅ ¡Conexión exitosa a MySQL!")

	// 3. Crear tabla (si no existe)
	_, err = db.Exec(`CREATE TABLE IF NOT EXISTS usuarios (
		id INT AUTO_INCREMENT PRIMARY KEY,
		nombre VARCHAR(50),
		email VARCHAR(100)
	)`)
	if err != nil {
		log.Fatal("Error al crear tabla:", err)
	}

	// 4. Insertar datos
	result, err := db.Exec("INSERT INTO usuarios (nombre, email) VALUES (?, ?)", "Ana López", "ana@example.com")
	if err != nil {
		log.Fatal("Error al insertar:", err)
	}
	id, _ := result.LastInsertId()
	fmt.Printf("📝 Usuario insertado (ID: %d)\n", id)

	// 5. Consultar datos
	rows, err := db.Query("SELECT id, nombre, email FROM usuarios")
	if err != nil {
		log.Fatal("Error al consultar:", err)
	}
	defer rows.Close()

	var usuarios []Usuario
	for rows.Next() {
		var u Usuario
		err = rows.Scan(&u.ID, &u.Nombre, &u.Email)
		if err != nil {
			log.Fatal("Error al escanear fila:", err)
		}
		usuarios = append(usuarios, u)
	}

	// 6. Mostrar resultados
	fmt.Println("\n📊 Lista de usuarios:")
	for _, usuario := range usuarios {
		fmt.Printf("ID: %d, Nombre: %s, Email: %s\n", usuario.ID, usuario.Nombre, usuario.Email)
	}
}

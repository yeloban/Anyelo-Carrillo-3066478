<?php
require 'vendor/autoload.php'; // Si usas Composer

// Configuración de la conexión
$mongoClient = new MongoClient("mongodb://localhost:27017");

try {
    // Verificar conexión
    $mongoClient->listDatabases(); // Test simple
    
    echo "✅ ¡Conexión exitosa a MongoDB!";
    
    // Seleccionar base de datos y colección
    $database = $mongoClient->mi_basedatos;
    $collection = $database->mi_coleccion;
    
    // Consultar documentos
    $documentos = $collection->find();
    foreach ($documentos as $doc) {
        echo "<pre>" . print_r($doc, true) . "</pre>";
    }

} 

catch (MongoDB\Driver\Exception\ConnectionTimeoutException $e) {
    echo "❌ Error de conexión: " . $e->getMessage();
}
?>
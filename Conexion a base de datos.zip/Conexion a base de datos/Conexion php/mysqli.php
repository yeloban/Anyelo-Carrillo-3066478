<?php

// Datos de conexión a la base de datos
$servername = "localhost"; // Dirección del servidor de la base de datos
$username = "root"; // Nombre de usuario de la base de datos
$password = ""; // Contraseña de la base de datos

// Crear la conexión
$conn = new mysqli($host, $username, $password);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

echo "Conexión exitosa";

// Aquí puedes realizar consultas a la base de datos

// Cerrar la conexión
$conn->close();
?>
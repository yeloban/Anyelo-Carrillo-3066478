<?php
try {
    $conn = new PDO("pgsql:host=localhost;dbname=test_db", "postgres", "tu_contraseña");
    echo "✅ ¡Conexión exitosa!";
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>

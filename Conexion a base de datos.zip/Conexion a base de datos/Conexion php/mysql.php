<?php
// Datos de conexión
$host = 'localhost'; // Servidor de la base de datos
$username = 'root'; // Usuario de la base de datos
$password = ''; // Contraseña de la base de datos

try {
    // Crear la conexión usando PDO (sin especificar la base de datos)
    $conn = new PDO("mysql:host=$host", $username, $password);

    // Configurar el modo de error para que PDO lance excepciones en caso de errores
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "✅ Conexión exitosa al servidor MySQL (sin base de datos seleccionada)";

    // Aquí puedes ejecutar consultas que no requieran una base de datos específica
    // Por ejemplo, listar las bases de datos disponibles:
    $query = $conn->query("SHOW DATABASES");
    $databases = $query->fetchAll(PDO::FETCH_COLUMN);

    
    echo "<br>Bases de datos disponibles:<br>";
    foreach ($databases as $db) {
        echo "- $db<br>";
    }

} catch (PDOException $e) {
    // Manejar errores de conexión
    die("❌ Error de conexión: " . $e->getMessage());
}

// Cerrar la conexión (opcional, ya que PHP la cierra automáticamente al finalizar el script)
$conn = null;
?>
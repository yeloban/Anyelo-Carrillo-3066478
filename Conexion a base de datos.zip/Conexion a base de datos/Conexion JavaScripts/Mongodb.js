// Importar el módulo mongodb
const { MongoClient } = require('mongodb');

// URL de conexión a MongoDB (reemplaza con tu cadena de conexión)
const uri = 'mongodb://localhost:27017'; // Cambia si usas MongoDB Atlas o otra configuración

// Nombre de la base de datos
const dbName = 'tu_base_de_datos'; // Reemplaza con el nombre de tu base de datos

// Crear un nuevo cliente de MongoDB
const client = new MongoClient(uri);

async function main() {
  try {
    // Conectar al servidor de MongoDB
    await client.connect();
    console.log('✅ Conexión exitosa a MongoDB');

    // Seleccionar la base de datos
    const db = client.db(dbName);

    // Ejemplo: Consultar una colección
    const collection = db.collection('tu_coleccion'); // Reemplaza con el nombre de tu colección
    const query = {}; // Consulta vacía para obtener todos los documentos
    const result = await collection.find(query).toArray();
    console.log('Resultado de la consulta:', result);
  } catch (err) {
    console.error('Error al conectar o consultar MongoDB:', err);
  } finally {
    // Cerrar la conexión
    await client.close();
  }
}

// Ejecutar la función principal
main().catch(console.error);
import psycopg2

try:
    # Establecer conexión con la base de datos postgreSQL.
    conn = psycopg2.connect(
        host="localhost",      # Dirección del servidor de la base de datos (en este caso, local)
        user="postgres",       # Usuario de postgreSQL (por defecto suele ser "postgres")
        password="3530",       # Contraseña del usuario
        port=5432             # Puerto de postgreSQL (por defecto 5432)
    )

    print(conn)
    print("✅ conexión exitosa")
    print(type(conn))

    # Crear un cursor para ejecutar consultas
    cursor = conn.cursor()

    # Listar todas las bases de datos disponibles
    cursor.execute("SELECT datname FROM pg_database")
    print("Base de datos disponibles:")
    for db in cursor:
        print(db)

    # Crear una nueva base de datos
    cursor.execute("CREATE DATABASE mydataficha3066478")
    print("✅ Base de datos 'mydataficha3066478' creada exitosamente")

except psycopg2.Error as err:
    # Captura errores de conexión y mostrarlos en pantalla
    print(f"❌ Error al conectar con postgreSQL: {err}")

finally:
    # Verificar si el cursor existe antes de cerrarlo
    if 'cursor' in locals() and cursor:
        cursor.close()
        print("🔌Cursor cerrado")

    #Verificar si la conexión existe antes de cerrarla
    if 'conn' in locals() and conn:
        conn.close()
        print("🔌conexión cerrada")

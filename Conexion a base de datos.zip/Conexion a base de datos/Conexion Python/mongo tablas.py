from pymongo import MongoClient

# Conectar a MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["ecommerce3066478"]

# Crear colecciones
clientes = db["clientes1"]
productos = db["productos1"]
ventas = db["ventas1"]
compras = db["compras1"]
compras = db["comercio1"]

# Insertar documentos de ejemplo
clientes.insert_one({"nombre": "Juan Pérez", "correo": "juan@gmail.com", "telefono": "123456789", "direccion": "calle 123"})
productos.insert_one({"nombre": "Laptop", "descripcion": "Laptop de alta gama", "precio": 1200, "stock": 10})

print("Base de datos y colecciones creadas en MongoDB")
import psycopg2

# conectar a PostgresSQL
conn = psycopg2.connect(
    dbname="postgres",
    user="postgres",    
    password="3530",
    host="localhost"
)

print("conexión exitosa")
print(conn)
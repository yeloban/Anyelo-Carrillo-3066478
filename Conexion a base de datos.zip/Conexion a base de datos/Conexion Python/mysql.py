

import mysql.connector

conn = mysql.connector.connect(
        host="localhost",  # Dirección del servidor de la base de datos
        user="root",       # Usuario de MySQL
        password="",       # Contraseña del usuario de MySQL (debe configurarse si tiene una)
    )

    # Si la conexión se establece correctamente, imprimimos un mensaje de éxito
print(conn)
print("✅ conexión exitosa")
print(f"🔍Tipo de objeto de conexión: {type(conn)}") # Muestra el tipo de objeto de conexión

    # Creamos un cursor para ejecutar comandos SQL
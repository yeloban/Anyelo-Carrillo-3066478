from pymongo import MongoClient

try:
    # Intentar crear la conexión
    cliente = MongoClient("mongodb://localhost:27017/")
    print("Conexión exitosa a MongoDB")

    # Aquí puedes realizar operaciones con la base de datos...

except Exception as e:
    print(f"Error al conectar a MongoDB: {e}")

finally:
    # Cerrar la conexión si está definida
    if 'cliente' in locals():
        cliente.close()
        print("Conexión cerrada")
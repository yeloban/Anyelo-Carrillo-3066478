# Instalar pymongo si no lo tienes
# pip install pymongo

# Importanbte la librería pymongo, que nos permite conectar y trabjar con base de datos MongoDB en Python
import pymongo

try:
    # Intentamos establecer la conexión con el servidor de mongoDB en la dirección  "localhost" y el puerto "27017"
    # Si MongoDB está ejecutándose localmente, esta conexión debería ser exitosa
    cliente = pymongo.MongoClient("mongo://localhost:27017/")

    # Si la conexión se establece correctamente, imprimimos el objeto de conexión
    print(cliente)

    #Mensaje de configuración de conexión exitosa
    print("✅ conexión exitosa")

    #Imprime el tipo de objeto creado (debería ser de tipo mongoClient)
    print(f"🔍 Tipo de objeto de conexión: {type(cliente)}")

    # Listar todas las bases de datos disponibles en el servidor de MongoDB y mostrarlas en la consola
    print("📂 Bases de datos disponibles:", cliente.list_database_names())

    # Creamos o accedemos a la base de datos llamada "mydatabase"
    mibasededatos = cliente["mydatabase"]

    # Creamos o accedemos a la colección llamada "mycollection" dentro de la base de datos
    micoleccion = mibasededatos["mycollection"]

    # Documento que se insertará en la colección
    documento = {"nombre": "Alice", "edad": 25, "ciudad": "wonderland"}

    # Insertamos el documento en la colección
    resultado = micoleccion.insert_one(documento)

    # Imprimimos el ID del documento insertado
    print(f"📌 Documento insertado con ID: {resultado.inseted_id}")

except Exception as e:
    # Capturamos cualquier error que ocurra durante la conexión o inserción de datos
    print("❌ Error:", e)

finally:
    # Cerramos la conexión con el servidor de MongoDB
    cliente.close()

    # Mensaje de confirmación indicando que la conexión ha sido cerrada 
    print("🔌 Conexión cerrada")
